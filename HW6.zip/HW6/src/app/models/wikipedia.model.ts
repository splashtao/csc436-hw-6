export class Wikipedia {
  constructor(
    public word: string,
    public description: string,
    public link: string) {}
}
