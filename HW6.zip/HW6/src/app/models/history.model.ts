export class SearchHistory {
  constructor(
    public timestamp: string,
    public searchWords: string) {}
}
